from django import forms
from .models import Comment


class CommentForm(forms.ModelForm):
    """Форма для добавления комментария"""
    class Meta:
        model = Comment
        fields = ["text"]
        widgets = {
            "text": forms.Textarea(attrs={"class": "form-control", "rows": 3, "placeholder": "Введите комментарий..."}),
        }


class MultipleFileInput(forms.ClearableFileInput):
    """Кастомный виджет для загрузки нескольких файлов"""
    allow_multiple_selected = True  # Включаем множественный выбор файлов


class FileUploadForm(forms.Form):
    """Форма загрузки файлов отдельно от комментария"""
    files = forms.FileField(
        widget=MultipleFileInput(attrs={"multiple": True}),
        required=False,
        label="Прикрепить файлы"
    )
